/*
 * Application.h
 *
 *  Created on: Apr 3, 2024
 *      Author: aaron
 */

#ifndef INC_APPLICATION_H_
#define INC_APPLICATION_H_

#include "Gyro_Driver.h"
#include "LCD_Driver.h"
#include "cmsis_os.h"
#include "math.h"







//██████████               ██████   ███
//░░███░░░░███             ███░░███ ░░░
//░███   ░░███  ██████   ░███ ░░░  ████  ████████    ██████   █████
//░███    ░███ ███░░███ ███████   ░░███ ░░███░░███  ███░░███ ███░░
//░███    ░███░███████ ░░░███░     ░███  ░███ ░███ ░███████ ░░█████
//░███    ███ ░███░░░    ░███      ░███  ░███ ░███ ░███░░░   ░░░░███
//██████████  ░░██████   █████     █████ ████ █████░░██████  ██████
//░░░░░░░░░░    ░░░░░░   ░░░░░     ░░░░░ ░░░░ ░░░░░  ░░░░░░  ░░░░░░

#define BUTTON_DRIVER_PORT GPIOA

#define LED_GPIO GPIOG
#define BUTTON_GPIO GPIOA

#define LED_DRIVER_GREEN_LED_PIN GPIO_PIN_13 //13
#define LED_DRIVER_RED_LED_PIN  GPIO_PIN_14 //14

#define LED_BUTTON_PIN GPIO_PIN_0

#define GYRO_LOWER_BOUND 8
#define GYRO_UPPER_BOUND 45

#define BUTTON_HELD 0
#define BUTTON_PRESSED 1

//Physics

#define GRAVITY 0.000981 //cm/ms^2
#define PHYS_TIME 50    //millisednds




//███████████                                 █████     ███
//░░███░░░░░░█                                ░░███     ░░░
//░███   █ ░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
//░███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███░░░█    ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███  ░     ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//█████       ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
//░░░░░         ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░

//INITS -----------------

void ApplicationInit(void);

void osThread_init();

void setupTasks();

void osEventInit();

void osMutexInit();

void osSemaphoreInit();

//GYRO Updates -------------



//Taks ---------------------
void Task1_Quantum_Burst(void *argument);

void Task2_LED_Drive(void *argument);

void Task3_Physics_Calc(void *argument);

void Task4_Display(void *argument);

void Task5_Obstical_Gen(void *argument);

void Task6_Gyro_read(void *argument);

//Other Funcs ---------------


#endif /* INC_APPLICATION_H_ */
