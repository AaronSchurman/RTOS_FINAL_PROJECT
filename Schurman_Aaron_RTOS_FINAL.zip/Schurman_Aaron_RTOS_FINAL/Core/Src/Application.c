/*
 * Application.c
 *
 *  Created on: Apr 3, 2024
 *      Author: aaron
 */


#include "Application.h"


//  █████████   █████                                   █████
// ███░░░░░███ ░░███                                   ░░███
//░███    ░░░  ███████   ████████  █████ ████  ██████  ███████    █████
//░░█████████ ░░░███░   ░░███░░███░░███ ░███  ███░░███░░░███░    ███░░
// ░░░░░░░░███  ░███     ░███ ░░░  ░███ ░███ ░███ ░░░   ░███    ░░█████
// ███    ░███  ░███ ███ ░███      ░███ ░███ ░███  ███  ░███ ███ ░░░░███
//░░█████████   ░░█████  █████     ░░████████░░██████   ░░█████  ██████
// ░░░░░░░░░     ░░░░░  ░░░░░       ░░░░░░░░  ░░░░░░     ░░░░░  ░░░░░░


//maybe make a direction untion to put in the struct. this calculation could be done in the physics task.


typedef enum{
	flagButton = (1<<0),
	flagLED = (1<<1)

}Flags;

typedef struct{

	float Vx;
	float Vy;
	float acclX;
	float acclY;
	float posX;
	float posY;
	float oldPosX;
	float oldPosY;
	float GYRO_DATA_X; //radians over time //sampling rate 20ms
	float GYRO_DATA_Y; //radians over time //sampling rate 20ms

}ballStuff;


typedef struct{

	GPIO_PinState BUTON;

}messageBoi;

//typedef struct {
//	uint32_t MAZE_WIDTH : (LCD_PIXEL_WIDTH_X - 15);
//	uint32_t MAZE_HEIGHT : (LCD_PIXEL_HIGHT_Y - 15);
//	uint32_t CELL_SIZE : 10;
//
//}Settings;

typedef struct{

	uint32_t rng;
	uint8_t draw;

}Obsticals;


//██████████                     ████                                 █████     ███
//░░███░░░░███                   ░░███                                ░░███     ░░░
//░███   ░░███  ██████   ██████  ░███   ██████   ████████   ██████   ███████   ████   ██████  ████████    █████
//░███    ░███ ███░░███ ███░░███ ░███  ░░░░░███ ░░███░░███ ░░░░░███ ░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███    ░███░███████ ░███ ░░░  ░███   ███████  ░███ ░░░   ███████   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███    ███ ░███░░░  ░███  ███ ░███  ███░░███  ░███      ███░░███   ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//██████████  ░░██████ ░░██████  █████░░████████ █████    ░░████████  ░░█████  █████░░██████  ████ █████ ██████
//░░░░░░░░░░    ░░░░░░   ░░░░░░  ░░░░░  ░░░░░░░░ ░░░░░      ░░░░░░░░    ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░

//------------------------STRUCTS---------------------------------
ballStuff ball = {.posX = LCD_PIXEL_WIDTH_X/2, .posY = LCD_PIXEL_HEIGHT_Y/2};
Obsticals Map;
Flags flags;

int wall_matrix[MAZE_WIDTH][MAZE_HEIGHT][2]; // Matrix to represent walls in the maze
int hole_matrix[MAZE_WIDTH][MAZE_HEIGHT];

//settings
MazeConfig mazeConfig = {
    .time_to_complete = 60000,
    .cell_size = CELL_SIZE,
    .width = MAZE_WIDTH,
    .height = MAZE_HEIGHT,
    .wall_probability = WALL_PROBABILITY,
    .hole_probability = HOLE_PROBABILITY,
    .hole_radius = HOLE_RADIUS,
    .hard_edged = 1,
    .num_waypoints = 2,
    .waypoint_diameter = 10,
    .reuse = 0,
    .waypoint_locations = {{10, 10}, {230, 215}}
};

int gameTime = 0;
int numWaypoints = 0;
int waypoint_diameter = 0;
int gameOver = 0;
int Lives = 3;
int disruptor = 0; //activation of disruptor
int waypoint_locations[2][2] = {{10, 10}, {228, 270}};
int hit1 = 0;
int hit2 = 0;
int win = 0;
int disruptor_duration = 2000;

//------------------------GLOBALS---------------------------------
GPIO_PinState ButtonPress;

static osMutexId_t mutexBall_id;
static osEventFlagsId_t eventID;
static osMessageQueueId_t messageID;
//------------------------TIMERS---------------------------------

//disruptor timer

static osTimerId_t disTimer;
static StaticTimer_t timerDis;

static osTimerAttr_t timerAttributes = {
        .name = "DisTime",
        .cb_mem = &timerDis,
        .cb_size = sizeof(timerDis)
};


//game timer

static osTimerId_t gameTimer;
static StaticTimer_t Gametcb;

static osTimerAttr_t gameTimerAttributes = {
        .name = "game",
        .cb_mem = &Gametcb,
        .cb_size = sizeof(Gametcb)
};

//timer callback

void gameCLKCallback(void *arg){
	(void)&arg;
//	osSemaphoreRelease(gyroSemaphore_ID);
	gameTime -= 100;
	if(gameTime <= 0){
		gameTime = 0;
		gameOver = 1;
	}
}

void DisCLKCallback(void *arg){
	(void)&arg;
	messageBoi mess;

//	osSemaphoreRelease(gyroSemaphore_ID);
	disruptor_duration -= 100;
	if(disruptor_duration <= 0){
		disruptor = 0;
		mess.BUTON = HAL_GPIO_ReadPin(BUTTON_DRIVER_PORT, LED_BUTTON_PIN);
		osStatus_t stat = osMessageQueuePut(messageID, &mess,0,0);
		if(stat != osOK){
			while(1);
		}
	}
}




//███████████                                 █████     ███
//░░███░░░░░░█                                ░░███     ░░░
//░███   █ ░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
//░███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███░░░█    ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███  ░     ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//█████       ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
//░░░░░         ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░


//------------------------INITS---------------------------------

void setupTasks(void) {

    HAL_NVIC_EnableIRQ(EXTI0_IRQn);

//    osStatus_t status;

    osThread_init();
    osSemaphoreInit();
    osEventInit();
    osMutexInit();
    osMessage_init();


    NVIC_SetPriority(EXTI0_IRQn, 13);
    // Enable interrupts for button press.
}

void ApplicationInit(void)
{
	LTCD__Init();
    LTCD_Layer_Init(0);
    LCD_Clear(LCD_COLOR_BLACK);
	LCD_SetTextColor(LCD_COLOR_BLACK);
	LCD_SetFont(&Font16x24);
    Gyro_Init();
    Init_RNG();
    maze_init(&mazeConfig);

    //set waypoints
//    waypoint_locations[0][0] = LCD_PIXEL_WIDTH_X / (getRNG() % 10);
//    waypoint_locations[0][1] = LCD_PIXEL_HEIGHT_Y / (getRNG() % 10);
//    waypoint_locations[1][0] = LCD_PIXEL_WIDTH_X / (getRNG() % 10);
//    waypoint_locations[1][1] = LCD_PIXEL_HEIGHT_Y / (getRNG() % 10);



    disTimer = osTimerNew(DisCLKCallback, osTimerPeriodic, NULL, &timerAttributes);
    if(disTimer == NULL) while(1);
    gameTimer = osTimerNew(gameCLKCallback, osTimerPeriodic, NULL, &gameTimerAttributes);
    if(gameTimer == NULL) while(1);

    osStatus_t osTimerBegin = osTimerStart(gameTimer, 100);
    while(osTimerBegin != osOK);

    gameTime = mazeConfig.time_to_complete;


}


/**
 * @brief Initializes a message queue.
 *
 * This function creates a message queue which can be used for inter-thread communication.
 */
void osMessage_init(){
	messageID = osMessageQueueNew(10, sizeof(messageBoi),NULL);

	if(messageID == NULL){
		while(1);
	}
}

void osEventInit(){

	eventID = osEventFlagsNew(NULL);
	if(eventID == NULL){
		while(1);
	}
}

void osMutexInit(){
	mutexBall_id = osMutexNew(NULL);
	if(mutexBall_id == NULL) while(1);
}

void osSemaphoreInit(){

}


void osThread_init(){

	static StaticTask_t Task1_Quantum_TCB;
	static uint32_t task1stack[320];
	static osThreadId_t task1_Quantum_ID;
	static const osThreadAttr_t Thread1Attribute = {
			.name = "Task1Speed",
			.cb_size = sizeof(Task1_Quantum_TCB),
			.cb_mem = &Task1_Quantum_TCB,
			.stack_mem = &task1stack,
			.stack_size = sizeof(task1stack),
			.priority = 1,
	};

	task1_Quantum_ID = osThreadNew(Task1_Quantum_Burst, NULL, &Thread1Attribute);
		if (task1_Quantum_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task2_LED_TCB;
	static uint32_t task2stack[320];
	static osThreadId_t task2_LED_ID;
	static const osThreadAttr_t Thread2Attribute = {
			.name = "Task2",
			.cb_size = sizeof(Task2_LED_TCB),
			.cb_mem = &Task2_LED_TCB,
			.stack_mem = &task2stack,
			.stack_size = sizeof(task2stack),
			.priority = 1,
	};


	task2_LED_ID = osThreadNew(Task2_LED_Drive, NULL, &Thread2Attribute);
		if (task2_LED_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task3_Phys_TCB;
	static uint32_t task3stack[320];
	static osThreadId_t task3_Phys_ID;
	static const osThreadAttr_t Thread3Attribute = {
			.name = "Task3",
			.cb_size = sizeof(Task3_Phys_TCB),
			.cb_mem = &Task3_Phys_TCB,
			.stack_mem = &task3stack,
			.stack_size = sizeof(task3stack),
			.priority = 1,
	};


	task3_Phys_ID = osThreadNew(Task3_Physics_Calc, NULL, &Thread3Attribute);
		if (task3_Phys_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task4_LCD_TCB;
	static uint32_t task4stack[320];
	static osThreadId_t task4_LCD_ID;
	static const osThreadAttr_t Thread4Attribute = {
			.name = "Task4",
			.cb_size = sizeof(Task4_LCD_TCB),
			.cb_mem = &Task4_LCD_TCB,
			.stack_mem = &task4stack,
			.stack_size = sizeof(task4stack),
			.priority = 1,
	};


	task4_LCD_ID = osThreadNew(Task4_Display, NULL, &Thread4Attribute);
		if (task4_LCD_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task5_OBS_TCB;
	static uint32_t task5stack[320];
	static osThreadId_t task5_OBS_ID;
	static const osThreadAttr_t Thread5Attribute = {
			.name = "Task5",
			.cb_size = sizeof(Task5_OBS_TCB),
			.cb_mem = &Task5_OBS_TCB,
			.stack_mem = &task5stack,
			.stack_size = sizeof(task5stack),
			.priority = 1,
	};
	task5_OBS_ID = osThreadNew(Task5_Obstical_Gen, NULL, &Thread5Attribute);
		if (task5_OBS_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}
}
//------------------------UPDATES-------------------------------


//------------------------TASKS---------------------------------

void Task1_Quantum_Burst(void *argument){
	(void) &argument;

	while(1){

		osDelay(1000);

//        uint32_t flags = osEventFlagsWait(eventID, flagButton, osFlagsWaitAny, osWaitForever);
//        if (flags < 0 ){
//				while(1);
//				//error, highest bit
//			}
//        flags = osEventFlagsClear(eventID, flagButton);
//        if (flags < 0 ){
//				while(1);
//				//error, highest bit
//			}
        messageBoi mess;
        mess.BUTON = HAL_GPIO_ReadPin(BUTTON_DRIVER_PORT, LED_BUTTON_PIN);
//        disruptor = 1;

		if (mess.BUTON == GPIO_PIN_SET) {
			disruptor_duration = 2000;
			osStatus_t osTimerBegin = osTimerStart(disTimer, 100);
			while(osTimerBegin != osOK);
			osStatus_t stat = osMessageQueuePut(messageID, &mess,0,0);
			if(stat != osOK){
				while(1);
			}
			disruptor = 1;
		}
	}
}


void Task2_LED_Drive(void *argument){
	(void) &argument;

	messageBoi mess;
//	GPIO_PinState ButtonPress;

	while(1){
//			osDelay(20);
			osStatus_t stat = osMessageQueueGet(messageID, &mess,0, osWaitForever);
			if(stat != osOK){
				while(1);
			}

		    if ((disruptor == 1 || mess.BUTON == GPIO_PIN_SET)) {
		        HAL_GPIO_WritePin(LED_GPIO, LED_DRIVER_RED_LED_PIN, GPIO_PIN_SET); // Turn on red LED.
//		        disruptor = 0;
		    } else {
		        HAL_GPIO_WritePin(LED_GPIO, LED_DRIVER_RED_LED_PIN, GPIO_PIN_RESET); // Turn off red LED.
		    }
		    if ((disruptor == 1|| mess.BUTON == GPIO_PIN_SET)) {
		        HAL_GPIO_WritePin(LED_GPIO, LED_DRIVER_GREEN_LED_PIN, GPIO_PIN_SET); // Turn on green LED.
//		        disruptor = 0;
		    } else {
		        HAL_GPIO_WritePin(LED_GPIO, LED_DRIVER_GREEN_LED_PIN, GPIO_PIN_RESET); // Turn off green LED.
		    }

	}
}


void Task3_Physics_Calc(void *argument){
	(void) &argument;

//	float old_acclX;
//	float old_acclY;
//	float old_vX;
//	float old_vY;
//	float old_posX;
//	float old_posY;

	while(1){


		osDelay(50);

		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

//		old_acclX = ball.acclX;
//		old_acclY = ball.acclY;
//		old_vX = ball.Vx;
//		old_vY = ball.Vy;
		ball.oldPosX = ball.posX;
		ball.oldPosY = ball.posY;

		int16_t yVal = Gyro_Get_Velocity_Y(); //CW = posotive //CCW = negative // right or left
		int16_t xVal = Gyro_Get_Velocity_X(); // same thing // should be away or twards

		//stationary jitter
		if(yVal < 1000 && yVal > -1000){
			yVal = 0;
		}
		if(xVal < 1000 && xVal > -1000){
			xVal = 0;
		}
		//flip axis and reverse values to make it playable a from a user perspective
		ball.GYRO_DATA_Y = (-xVal/1000 * 50);
		ball.GYRO_DATA_X = (-yVal/1000 * 50);

		ball.acclX = GRAVITY * (sin(ball.GYRO_DATA_X)); // cm/ms^2 * rad/ms
		ball.acclY = GRAVITY * (sin(ball.GYRO_DATA_Y));
		ball.Vx += ball.acclX * PHYS_TIME;               // cm/ms
		ball.Vy += ball.acclY * PHYS_TIME;               // cm/ms
		ball.posX += ball.Vx * PHYS_TIME;                 // cm
		ball.posY += ball.Vy * PHYS_TIME;                 // cm

		if(ball.posX < 5 || ball.posX > LCD_PIXEL_WIDTH_X - 5){
			ball.posX = ball.oldPosX;
		}
		if(ball.posY < 5 || ball.posY > LCD_PIXEL_HEIGHT_Y - 5){
			ball.posY = ball.oldPosY;
		}

        // Check for collision with walls
        int current_cell_x = (int)ball.posX / CELL_SIZE;
        int current_cell_y = (int)ball.posY / CELL_SIZE;

        // Check collision with right wall
		if (ball.posX + 5 >= (current_cell_x + 1) * CELL_SIZE && wall_matrix[current_cell_x][current_cell_y][0] == 1 && disruptor == 0) {
			ball.posX = (current_cell_x + 1) * CELL_SIZE - 6;
			ball.Vx = 0;
		}
		// Check collision with bottom wall
		if (ball.posY + 5 >= (current_cell_y + 1) * CELL_SIZE && wall_matrix[current_cell_x][current_cell_y][1] == 1 && disruptor == 0) {
			ball.posY = (current_cell_y + 1) * CELL_SIZE - 6;
			ball.Vy = 0;
		}
		// Check collision with left wall
		if (ball.posX - 5 <= current_cell_x * CELL_SIZE && wall_matrix[current_cell_x - 1][current_cell_y][0] == 1 && disruptor == 0) {
			ball.posX = current_cell_x * CELL_SIZE + 6;
			ball.Vx = 0;
		}
		// Check collision with top wall
		if (ball.posY - 5 <= current_cell_y * CELL_SIZE && wall_matrix[current_cell_x][current_cell_y - 1][1] == 1 && disruptor == 0) {
			ball.posY = current_cell_y * CELL_SIZE + 6;
			ball.Vy = 0;
		}

		//hole collision detection
        if (!disruptor && wall_matrix[current_cell_x][current_cell_y][0] == 0 && wall_matrix[current_cell_x][current_cell_y][1] == 0 && Map.draw == 1) {

        	Lives--;
        	Map.draw = 0;

			if (Lives == 0) {
				gameOver = 1; //end game
			}
        }

        if(current_cell_x == 0 && current_cell_y == 0){ // fist waypoint
        	waypoint_locations[0][0] = 0;
        	hit1 = 1;
        	}
        if(current_cell_x >= MAZE_WIDTH - 1 && current_cell_y >= MAZE_HEIGHT - 1){ // fist waypoint
        	waypoint_locations[1][0] = 0;
        	hit2 = 1;
        	}

        if(hit1 && hit2){
        	gameOver = 1;
        	win = 1;
        }


		status = osMutexRelease(mutexBall_id);
		while(status != osOK);
	}
}

void Task4_Display(void *argument){
	(void) &argument;

	while(1){

		osDelay(16);

		numWaypoints = mazeConfig.num_waypoints;
		waypoint_diameter = mazeConfig.waypoint_diameter;



		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

		if(gameOver != 1){
			LCD_Clear(LCD_COLOR_WHITE);
	//		LCD_Draw_Circle_Fill(ball.oldPosX,ball.oldPosY,5,LCD_COLOR_WHITE);
			LCD_Draw_Circle_Fill(ball.posX,ball.posY,5,LCD_COLOR_BLACK);

			for (int i = 0; i < MAZE_WIDTH; i++) {
					  for (int j = 0; j < MAZE_HEIGHT; j++) {

						  if (wall_matrix[i][j][0] == 1) {

							  LCD_Draw_Vertical_Line((i+1) * CELL_SIZE, j * CELL_SIZE, CELL_SIZE, LCD_COLOR_BLACK);
						  }
						  if (wall_matrix[i][j][1] == 1) {

							  LCD_Draw_Horizontal_Line(i * CELL_SIZE, (j+1) * CELL_SIZE, CELL_SIZE, LCD_COLOR_BLACK);
						  }
						if (wall_matrix[i][j][0] == 0 && wall_matrix[i][j][1] == 0 && Map.draw == 1) {
							 LCD_Draw_Circle_Fill(i * CELL_SIZE + CELL_SIZE / 2, j * CELL_SIZE + CELL_SIZE / 2, mazeConfig.hole_radius, LCD_COLOR_RED);
						 }
					  }
					}


			for (int k = 0; k < numWaypoints; k++) {
				int waypoint_x = waypoint_locations[k][0];
				int waypoint_y = waypoint_locations[k][1];
				if(waypoint_x != 0){
					LCD_Draw_Circle_Fill(waypoint_x, waypoint_y, waypoint_diameter / 2, LCD_COLOR_GREEN);
				}
			}

			char lives[20];
			sprintf(lives, "L:%d", Lives);
			LCD_SetTextColor(LCD_COLOR_BLUE);
			LCD_DisplayString(10, LCD_PIXEL_HEIGHT_Y - 20, lives);

			char time_str[20];
			sprintf(time_str, "T:%d", gameTime / 1000); // Convert remaining time to seconds
			LCD_DisplayString(160, LCD_PIXEL_HEIGHT_Y - 20, time_str);

			status = osMutexRelease(mutexBall_id);
			while(status != osOK);
		}
		else{
			if(win == 1){
				char time_str[30];
				//display congrats screen
				LCD_Clear(LCD_COLOR_BLACK);
				LCD_SetTextColor(LCD_COLOR_GREEN);
				LCD_DisplayString(65, 100, "Good Job");
				sprintf(time_str, "Time Left:%d", gameTime / 1000);
				LCD_DisplayString(25, 200, time_str);

			}
			else{
				//display fail screen
				LCD_Clear(LCD_COLOR_BLACK);
				LCD_SetTextColor(LCD_COLOR_GREEN);
				LCD_DisplayString(65, 100, "OOOOF");
			}
		}
	}
}

void Task5_Obstical_Gen(void *argument){ // decides if there will be holes or not
	(void) &argument;

	while(1){
		osDelay(1000);
		if(getRNG() % 2 == 0 ){
			Map.draw = 1;
		}
		else{
			Map.draw = 0;
		}
	}
}


//------------------------TIMER_CALLBACKS-----------------------




//------------------------Other---------------------------------

// Function to initialize the maze grid

int wall_matrix[MAZE_WIDTH][MAZE_HEIGHT][2];
int hole_matrix[MAZE_WIDTH][MAZE_HEIGHT];
void maze_init(MazeConfig *config) {

    // Initialize the wall_matrix with all walls present
    for (int i = 0; i < config->width; i++) {
        for (int j = 0; j < config->height; j++) {
            wall_matrix[i][j][0] = 1; // Right wall
            wall_matrix[i][j][1] = 1; // Bottom wall
            hole_matrix[i][j] = 0; // Initialize hole_matrix to 0 (no holes)
        }
    }

    // Start DFS from the starting cell (0, 0)
    dfs(0, 0, config);
    for (int i = 0; i < config->width; i++) {
        for (int j = 0; j < config->height; j++) {
            int holeRand = getRNG() % 100; // Generate a new random number for each cell
            if (holeRand < config->hole_probability) {
                wall_matrix[i][j][0] = 0; // Remove right wall
                wall_matrix[i][j][1] = 0; // Remove bottom wall
                hole_matrix[i][j] = getRNG()%2; // Mark the cell as having a hole
            }
        }
    }

    // Remove walls at waypoint locations
    for (int k = 0; k < config->num_waypoints; k++) {
        int x = config->waypoint_locations[k][0];
        int y = config->waypoint_locations[k][1];
        wall_matrix[x][y][0] = 0; // Remove right wall
        wall_matrix[x][y][1] = 0; // Remove bottom wall
        hole_matrix[x][y] = 0;
    }
}


void dfs(int x, int y, MazeConfig *config) {
    // Define the possible directions (right, down, left, up)
    int dx[] = {1, 0, -1, 0};
    int dy[] = {0, 1, 0, -1};

    // Shuffle the direction order randomly
    for (int i = 0; i < 4; i++) {
        int r = getRNG() % 4;
        int temp = dx[i];
        dx[i] = dx[r];
        dx[r] = temp;
        temp = dy[i];
        dy[i] = dy[r];
        dy[r] = temp;
    }

    // Visit each unvisited neighboring cell
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];

        // Check if the neighboring cell is within the maze boundaries
        if (nx >= 0 && nx < config->width && ny >= 0 && ny < config->height) {
            // Check if the neighboring cell is unvisited (has all walls intact)
            if (wall_matrix[nx][ny][0] && wall_matrix[nx][ny][1]) {
                // Remove the wall between the current cell and the neighboring cell
                if (dx[i] == 1) {
                    wall_matrix[x][y][0] = 0; // Remove right wall
                } else if (dx[i] == -1) {
                    wall_matrix[nx][ny][0] = 0; // Remove left wall
                } else if (dy[i] == 1) {
                    wall_matrix[x][y][1] = 0; // Remove bottom wall
                } else if (dy[i] == -1) {
                    wall_matrix[nx][ny][1] = 0; // Remove top wall
                }

                // Recursively visit the neighboring cell
                dfs(nx, ny, config);
            }
        }
    }
}


/**
 * @brief Updates the global button state variable.
 *
 * This function reads the current state of the button and updates a global variable accordingly.
 */
void ButtonState(void) {
    ButtonPress = HAL_GPIO_ReadPin(BUTTON_DRIVER_PORT, LED_BUTTON_PIN); // Update button state.
}

void EXTI0_IRQHandler(void) {

    HAL_NVIC_DisableIRQ(EXTI0_IRQn); // Disable EXTI0 interrupt.

    //code for button interupt here//
    osEventFlagsSet(eventID, flagButton); // Use an appropriate flag bit

    __HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0); // Clear interrupt flag.
    HAL_NVIC_EnableIRQ(EXTI0_IRQn); // Re-enable EXTI0 interrupt.
}







