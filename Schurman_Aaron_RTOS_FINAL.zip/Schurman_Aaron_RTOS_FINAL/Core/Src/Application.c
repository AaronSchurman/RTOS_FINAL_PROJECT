/*
 * Application.c
 *
 *  Created on: Apr 3, 2024
 *      Author: aaron
 */


#include "Application.h"


//  █████████   █████                                   █████
// ███░░░░░███ ░░███                                   ░░███
//░███    ░░░  ███████   ████████  █████ ████  ██████  ███████    █████
//░░█████████ ░░░███░   ░░███░░███░░███ ░███  ███░░███░░░███░    ███░░
// ░░░░░░░░███  ░███     ░███ ░░░  ░███ ░███ ░███ ░░░   ░███    ░░█████
// ███    ░███  ░███ ███ ░███      ░███ ░███ ░███  ███  ░███ ███ ░░░░███
//░░█████████   ░░█████  █████     ░░████████░░██████   ░░█████  ██████
// ░░░░░░░░░     ░░░░░  ░░░░░       ░░░░░░░░  ░░░░░░     ░░░░░  ░░░░░░


//maybe make a direction untion to put in the struct. this calculation could be done in the physics task.


typedef enum{
	away,
	hard_away,
	holdY,
	hard_twrd,
	twrd
}dirX;

typedef enum{
	left,
	hard_left,
	holdX,
	right,
	hard_right
}dirY;


typedef enum{
	flagA = (1<<0),
	flagb = (1<<1)

}Flags;

typedef struct{

	int32_t Angle;
	uint32_t Vx;
	uint32_t Vy;
	dirX x_rotation;
	dirY y_rotation;

}ballStuff;




//██████████                     ████                                 █████     ███
//░░███░░░░███                   ░░███                                ░░███     ░░░
//░███   ░░███  ██████   ██████  ░███   ██████   ████████   ██████   ███████   ████   ██████  ████████    █████
//░███    ░███ ███░░███ ███░░███ ░███  ░░░░░███ ░░███░░███ ░░░░░███ ░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███    ░███░███████ ░███ ░░░  ░███   ███████  ░███ ░░░   ███████   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███    ███ ░███░░░  ░███  ███ ░███  ███░░███  ░███      ███░░███   ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//██████████  ░░██████ ░░██████  █████░░████████ █████    ░░████████  ░░█████  █████░░██████  ████ █████ ██████
//░░░░░░░░░░    ░░░░░░   ░░░░░░  ░░░░░  ░░░░░░░░ ░░░░░      ░░░░░░░░    ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░

//------------------------STRUCTS---------------------------------
ballStuff ball;
Flags flags;

//------------------------GLOBALS---------------------------------
GPIO_PinState ButtonPress;

static osMutexId_t mutexBall_id;

//------------------------TIMERS---------------------------------




//███████████                                 █████     ███
//░░███░░░░░░█                                ░░███     ░░░
//░███   █ ░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
//░███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███░░░█    ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███  ░     ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//█████       ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
//░░░░░         ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░


//------------------------INITS---------------------------------

void setupTasks(void) {

    HAL_NVIC_EnableIRQ(EXTI0_IRQn);

    osStatus_t status;

    osThread_init();
    osSemaphoreInit();
    osEventInit();
    osMutexInit();

    NVIC_SetPriority(EXTI0_IRQn, 13);
    // Enable interrupts for button press.
}

void ApplicationInit(void)
{
	LTCD__Init();
    LTCD_Layer_Init(0);
    LCD_Clear(0,LCD_COLOR_BLACK);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_SetFont(&Font16x24);
    Gyro_Init();
}

void osEventInit(){

}

void osMutexInit(){
	mutexBall_id = osMutexNew(NULL);
	if(mutexBall_id == NULL) while(1);
}

void osSemaphoreInit(){

}


void osThread_init(){

	static StaticTask_t Task1_Quantum_TCB;
	static uint32_t task1stack[320];
	static osThreadId_t task1_Quantum_ID;
	static const osThreadAttr_t Thread1Attribute = {
			.name = "Task1Speed",
			.cb_size = sizeof(Task1_Quantum_TCB),
			.cb_mem = &Task1_Quantum_TCB,
			.stack_mem = &task1stack,
			.stack_size = sizeof(task1stack),
			.priority = 1,
	};

	task1_Quantum_ID = osThreadNew(Task1_Quantum_Burst, NULL, &Thread1Attribute);
		if (task1_Quantum_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task2_LED_TCB;
	static uint32_t task2stack[320];
	static osThreadId_t task2_LED_ID;
	static const osThreadAttr_t Thread2Attribute = {
			.name = "Task2",
			.cb_size = sizeof(Task2_LED_TCB),
			.cb_mem = &Task2_LED_TCB,
			.stack_mem = &task2stack,
			.stack_size = sizeof(task2stack),
			.priority = 1,
	};


	task2_LED_ID = osThreadNew(Task2_LED_Drive, NULL, &Thread2Attribute);
		if (task2_LED_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task3_Phys_TCB;
	static uint32_t task3stack[320];
	static osThreadId_t task3_Phys_ID;
	static const osThreadAttr_t Thread3Attribute = {
			.name = "Task3",
			.cb_size = sizeof(Task3_Phys_TCB),
			.cb_mem = &Task3_Phys_TCB,
			.stack_mem = &task3stack,
			.stack_size = sizeof(task3stack),
			.priority = 1,
	};


	task3_Phys_ID = osThreadNew(Task3_Physics_Calc, NULL, &Thread3Attribute);
		if (task3_Phys_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task4_LCD_TCB;
	static uint32_t task4stack[320];
	static osThreadId_t task4_LCD_ID;
	static const osThreadAttr_t Thread4Attribute = {
			.name = "Task4",
			.cb_size = sizeof(Task4_LCD_TCB),
			.cb_mem = &Task4_LCD_TCB,
			.stack_mem = &task4stack,
			.stack_size = sizeof(task4stack),
			.priority = 1,
	};


	task4_LCD_ID = osThreadNew(Task4_Display, NULL, &Thread4Attribute);
		if (task4_LCD_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task5_OBS_TCB;
	static uint32_t task5stack[320];
	static osThreadId_t task5_OBS_ID;
	static const osThreadAttr_t Thread5Attribute = {
			.name = "Task5",
			.cb_size = sizeof(Task5_OBS_TCB),
			.cb_mem = &Task5_OBS_TCB,
			.stack_mem = &task5stack,
			.stack_size = sizeof(task5stack),
			.priority = 1,
	};
	task5_OBS_ID = osThreadNew(Task5_Obstical_Gen, NULL, &Thread5Attribute);
		if (task5_OBS_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task6_GYRO_TCB;
	static uint32_t task6stack[320];
	static osThreadId_t task6_GYRO_ID;
	static const osThreadAttr_t Thread6Attribute = {
			.name = "Task6",
			.cb_size = sizeof(Task6_GYRO_TCB),
			.cb_mem = &Task6_GYRO_TCB,
			.stack_mem = &task6stack,
			.stack_size = sizeof(task6stack),
			.priority = 1,
	};
	task6_GYRO_ID = osThreadNew(Task6_Gyro_read, NULL, &Thread6Attribute);
		if (task6_GYRO_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}
}

//------------------------UPDATES-------------------------------




//------------------------TASKS---------------------------------

void Task1_Quantum_Burst(void *argument){
	(void) &argument;

	while(1){

	}
}


void Task2_LED_Drive(void *argument){
	(void) &argument;

	while(1){

	}
}


void Task3_Physics_Calc(void *argument){
	(void) &argument;

	int16_t yVal;
	int16_t xVal;
	int32_t angle;
	dirX Xd;
	dirY Yd;


	while(1){


		osDelay(100);

		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

		angle = ball.Angle;

		xVal = angle & 0xffff;
		yVal = (angle >> 16) & 0xffff;

		if(yVal > 12000)
			Yd = hard_right;
		else if(yVal > 1000)
			Yd = right;
		else if(yVal > -1000)
			Yd = holdY;
		else if(yVal > -12000)
			Yd = left;
		else
			Yd = hard_left;

		if(xVal > 12000)
			Xd = away;
		else if(xVal > 1000)
			Xd = hard_away;
		else if(xVal > -1000)
			Xd = holdX;
		else if(xVal > -12000)
			Xd = twrd;
		else
			Xd = hard_twrd;

		ball.x_rotation = Xd;
		ball.y_rotation = Yd;



		status = osMutexRelease(mutexBall_id);
		while(status != osOK);

	}
}

void Task4_Display(void *argument){
	(void) &argument;

	uint16_t Xpos = 100;
	uint16_t Ypos = 100;

	while(1){

		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

		dirX Xd = ball.x_rotation;
		dirY Yd = ball.y_rotation;

		if(Yd == hard_right || Yd == right){
			Ypos++;
		}
		else if(Yd == holdY){

		}
		else{
			Ypos--;
		}

		if(Xd == away || Xd == hard_away){
			Xpos++;
		}
		else if(Xd == holdX){

		}
		else{
			Xpos--;
		}

		LCD_Clear(0,LCD_COLOR_WHITE);
		LCD_Draw_Circle_Fill(Xpos,Ypos,10,LCD_COLOR_BLACK);

		status = osMutexRelease(mutexBall_id);
		while(status != osOK);

	}
}

void Task5_Obstical_Gen(void *argument){
	(void) &argument;

	while(1){

	}
}

void Task6_Gyro_read(void *argument){
	(void) &argument;

	while(1){

		//wait for clock
		osDelay(100);
		int32_t Direction = 0;

		//read gyro and place in struct
		int16_t yVal = Gyro_Get_Velocity_Y(); //CW = posotive //CCW = negative // right or left
		int16_t xVal = Gyro_Get_Velocity_X(); // same thing // should be away or twards

		Direction = Direction | yVal;
		Direction = Direction << 16;
		Direction = Direction | xVal;

		ball.Angle = Direction;

	}
}


//------------------------TIMER_CALLBACKS-----------------------




//------------------------Other---------------------------------


void EXTI0_IRQHandler(void) {

    HAL_NVIC_DisableIRQ(EXTI0_IRQn); // Disable EXTI0 interrupt.

    //code for button interupt here//



    __HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0); // Clear interrupt flag.
    HAL_NVIC_EnableIRQ(EXTI0_IRQn); // Re-enable EXTI0 interrupt.
}







