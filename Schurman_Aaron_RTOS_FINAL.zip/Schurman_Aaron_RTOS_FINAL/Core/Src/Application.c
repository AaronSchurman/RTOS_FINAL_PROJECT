/*
 * Application.c
 *
 *  Created on: Apr 3, 2024
 *      Author: aaron
 */


#include "Application.h"


//  █████████   █████                                   █████
// ███░░░░░███ ░░███                                   ░░███
//░███    ░░░  ███████   ████████  █████ ████  ██████  ███████    █████
//░░█████████ ░░░███░   ░░███░░███░░███ ░███  ███░░███░░░███░    ███░░
// ░░░░░░░░███  ░███     ░███ ░░░  ░███ ░███ ░███ ░░░   ░███    ░░█████
// ███    ░███  ░███ ███ ░███      ░███ ░███ ░███  ███  ░███ ███ ░░░░███
//░░█████████   ░░█████  █████     ░░████████░░██████   ░░█████  ██████
// ░░░░░░░░░     ░░░░░  ░░░░░       ░░░░░░░░  ░░░░░░     ░░░░░  ░░░░░░


//maybe make a direction untion to put in the struct. this calculation could be done in the physics task.


typedef enum{
	flagA = (1<<0),
	flagb = (1<<1)

}Flags;

typedef struct{

	float Vx;
	float Vy;
	float acclX;
	float acclY;
	float posX;
	float posY;
	float GYRO_DATA_X; //radians over time //sampling rate 20ms
	float GYRO_DATA_Y; //radians over time //sampling rate 20ms

}ballStuff;




//██████████                     ████                                 █████     ███
//░░███░░░░███                   ░░███                                ░░███     ░░░
//░███   ░░███  ██████   ██████  ░███   ██████   ████████   ██████   ███████   ████   ██████  ████████    █████
//░███    ░███ ███░░███ ███░░███ ░███  ░░░░░███ ░░███░░███ ░░░░░███ ░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███    ░███░███████ ░███ ░░░  ░███   ███████  ░███ ░░░   ███████   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███    ███ ░███░░░  ░███  ███ ░███  ███░░███  ░███      ███░░███   ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//██████████  ░░██████ ░░██████  █████░░████████ █████    ░░████████  ░░█████  █████░░██████  ████ █████ ██████
//░░░░░░░░░░    ░░░░░░   ░░░░░░  ░░░░░  ░░░░░░░░ ░░░░░      ░░░░░░░░    ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░

//------------------------STRUCTS---------------------------------
ballStuff ball = {.posX = 100, .posY = 150};

Flags flags;

//------------------------GLOBALS---------------------------------
GPIO_PinState ButtonPress;

static osMutexId_t mutexBall_id;

//------------------------TIMERS---------------------------------




//███████████                                 █████     ███
//░░███░░░░░░█                                ░░███     ░░░
//░███   █ ░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
//░███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
//░███░░░█    ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
//░███  ░     ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
//█████       ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
//░░░░░         ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░


//------------------------INITS---------------------------------

void setupTasks(void) {

    HAL_NVIC_EnableIRQ(EXTI0_IRQn);

//    osStatus_t status;

    osThread_init();
    osSemaphoreInit();
    osEventInit();
    osMutexInit();

    NVIC_SetPriority(EXTI0_IRQn, 13);
    // Enable interrupts for button press.
}

void ApplicationInit(void)
{
	LTCD__Init();
    LTCD_Layer_Init(0);
    LCD_Clear(LCD_COLOR_BLACK);
	LCD_SetTextColor(LCD_COLOR_BLACK);
	LCD_SetFont(&Font16x24);
    Gyro_Init();
}

void osEventInit(){

}

void osMutexInit(){
	mutexBall_id = osMutexNew(NULL);
	if(mutexBall_id == NULL) while(1);
}

void osSemaphoreInit(){

}


void osThread_init(){

	static StaticTask_t Task1_Quantum_TCB;
	static uint32_t task1stack[320];
	static osThreadId_t task1_Quantum_ID;
	static const osThreadAttr_t Thread1Attribute = {
			.name = "Task1Speed",
			.cb_size = sizeof(Task1_Quantum_TCB),
			.cb_mem = &Task1_Quantum_TCB,
			.stack_mem = &task1stack,
			.stack_size = sizeof(task1stack),
			.priority = 1,
	};

	task1_Quantum_ID = osThreadNew(Task1_Quantum_Burst, NULL, &Thread1Attribute);
		if (task1_Quantum_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task2_LED_TCB;
	static uint32_t task2stack[320];
	static osThreadId_t task2_LED_ID;
	static const osThreadAttr_t Thread2Attribute = {
			.name = "Task2",
			.cb_size = sizeof(Task2_LED_TCB),
			.cb_mem = &Task2_LED_TCB,
			.stack_mem = &task2stack,
			.stack_size = sizeof(task2stack),
			.priority = 1,
	};


	task2_LED_ID = osThreadNew(Task2_LED_Drive, NULL, &Thread2Attribute);
		if (task2_LED_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task3_Phys_TCB;
	static uint32_t task3stack[320];
	static osThreadId_t task3_Phys_ID;
	static const osThreadAttr_t Thread3Attribute = {
			.name = "Task3",
			.cb_size = sizeof(Task3_Phys_TCB),
			.cb_mem = &Task3_Phys_TCB,
			.stack_mem = &task3stack,
			.stack_size = sizeof(task3stack),
			.priority = 1,
	};


	task3_Phys_ID = osThreadNew(Task3_Physics_Calc, NULL, &Thread3Attribute);
		if (task3_Phys_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task4_LCD_TCB;
	static uint32_t task4stack[320];
	static osThreadId_t task4_LCD_ID;
	static const osThreadAttr_t Thread4Attribute = {
			.name = "Task4",
			.cb_size = sizeof(Task4_LCD_TCB),
			.cb_mem = &Task4_LCD_TCB,
			.stack_mem = &task4stack,
			.stack_size = sizeof(task4stack),
			.priority = 1,
	};


	task4_LCD_ID = osThreadNew(Task4_Display, NULL, &Thread4Attribute);
		if (task4_LCD_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task5_OBS_TCB;
	static uint32_t task5stack[320];
	static osThreadId_t task5_OBS_ID;
	static const osThreadAttr_t Thread5Attribute = {
			.name = "Task5",
			.cb_size = sizeof(Task5_OBS_TCB),
			.cb_mem = &Task5_OBS_TCB,
			.stack_mem = &task5stack,
			.stack_size = sizeof(task5stack),
			.priority = 1,
	};
	task5_OBS_ID = osThreadNew(Task5_Obstical_Gen, NULL, &Thread5Attribute);
		if (task5_OBS_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}

	static StaticTask_t Task6_GYRO_TCB;
	static uint32_t task6stack[320];
	static osThreadId_t task6_GYRO_ID;
	static const osThreadAttr_t Thread6Attribute = {
			.name = "Task6",
			.cb_size = sizeof(Task6_GYRO_TCB),
			.cb_mem = &Task6_GYRO_TCB,
			.stack_mem = &task6stack,
			.stack_size = sizeof(task6stack),
			.priority = 1,
	};
	task6_GYRO_ID = osThreadNew(Task6_Gyro_read, NULL, &Thread6Attribute);
		if (task6_GYRO_ID == NULL) {
			while(1); // Infinite loop if thread creation fails
		}
}

//------------------------UPDATES-------------------------------




//------------------------TASKS---------------------------------

void Task1_Quantum_Burst(void *argument){
	(void) &argument;

	while(1){

	}
}


void Task2_LED_Drive(void *argument){
	(void) &argument;

	while(1){

	}
}


void Task3_Physics_Calc(void *argument){
	(void) &argument;

	float old_acclX = ball.acclX;
	float old_acclY = ball.acclY;
	float old_vX = ball.Vx;
	float old_vY = ball.Vy;
	float old_posX = ball.posX;
	float old_posY = ball.posY;

	while(1){


		osDelay(50);

		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

		int16_t yVal = Gyro_Get_Velocity_Y(); //CW = posotive //CCW = negative // right or left
		int16_t xVal = Gyro_Get_Velocity_X(); // same thing // should be away or twards

		if(yVal < 1000 && yVal > -1000){
			yVal = 0;
		}
		if(xVal < 1000 && xVal > -1000){
			xVal = 0;
		}

//		ball.GYRO_DATA_X = xVal;
//		ball.GYRO_DATA_Y = yVal;

		ball.GYRO_DATA_Y = (-xVal/1000 * 50);
		ball.GYRO_DATA_X = (-yVal/1000 * 50);

		ball.acclX = GRAVITY * (sin(ball.GYRO_DATA_X)); // cm/ms^2 * rad/ms
		ball.acclY = GRAVITY * (sin(ball.GYRO_DATA_Y));
		ball.Vx += ball.acclX * PHYS_TIME;               // cm/ms
		ball.Vy += ball.acclY * PHYS_TIME;               // cm/ms
		ball.posX += ball.Vx * PHYS_TIME;                 // cm
		ball.posY += ball.Vy * PHYS_TIME;                 // cm

		status = osMutexRelease(mutexBall_id);
		while(status != osOK);
	}
}

void Task4_Display(void *argument){
	(void) &argument;


	uint16_t num = 500;

	while(1){

		osDelay(16);

		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
		while(status != osOK);

		if(ball.posX < 20 || ball.posX > 200){
			ball.posX = 100;
		}
		if(ball.posY < 20 || ball.posY > 300){
			ball.posY = 150;
		}

		LCD_Clear(LCD_COLOR_WHITE);
		LCD_Draw_Circle_Fill(ball.posX,ball.posY,10,LCD_COLOR_BLACK);
		//LCD_DisplayChar(50,50,ball.GYRO_DATA_X);
		//LCD_DisplayChar(50,100,ball.GYRO_DATA_Y);

		status = osMutexRelease(mutexBall_id);
		while(status != osOK);

	}
}

void Task5_Obstical_Gen(void *argument){
	(void) &argument;

	while(1){

	}
}

void Task6_Gyro_read(void *argument){
	(void) &argument;

	while(1){

//		osDelay(20);
//
//		osStatus_t status = osMutexAcquire(mutexBall_id, osWaitForever);
//		while(status != osOK);
//
//		//read gyro and place in struct
//		float yVal = Gyro_Get_Velocity_Y(); //CW = posotive //CCW = negative // right or left
//		float xVal = Gyro_Get_Velocity_X(); // same thing // should be away or twards
//
//		ball.GYRO_DATA_X += (xVal/1000000) * .02;
//		ball.GYRO_DATA_Y += (yVal/1000000) * .02;
//
//		status = osMutexRelease(mutexBall_id);
//		while(status != osOK);

	}
}


//------------------------TIMER_CALLBACKS-----------------------




//------------------------Other---------------------------------


void EXTI0_IRQHandler(void) {

    HAL_NVIC_DisableIRQ(EXTI0_IRQn); // Disable EXTI0 interrupt.

    //code for button interupt here//



    __HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0); // Clear interrupt flag.
    HAL_NVIC_EnableIRQ(EXTI0_IRQn); // Re-enable EXTI0 interrupt.
}







